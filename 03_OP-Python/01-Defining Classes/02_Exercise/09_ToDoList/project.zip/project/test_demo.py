from project.task import Task
from project.section import Section

task_1 = Task("T1", "01.01.2001")
task_2 = Task("T2", "02.02.2002")

section_1 = Section("S1")

task_1.add_comment("Commend 1")
task_1.add_comment("Commend 2")

print(task_1.edit_comment(-1, "New_commend_1"))
print(task_1.edit_comment(1, "New_commend_2"))
print(task_1.edit_comment(2, "New_commend_3"))

print(section_1.add_task(task_1))
print(section_1.add_task(task_2))
print(section_1.add_task(task_2))

print(section_1.complete_task("T1"))
print(section_1.complete_task("T1"))
print(section_1.complete_task("False"))

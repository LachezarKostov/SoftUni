from project import *

heroes = [
    Hero("hero", 1),
    Elf("elf", 2),
    Wizard("Wizard", 3),
    Knight("Knight", 4),
    MuseElf("ME", 5),
    DarkKnight("DK", 6),
    DarkWizard("DW", 7),
    SoulMaster("SM", 8),
    BladeKnight("BK", 9),
]

for h in heroes:
    print(h)


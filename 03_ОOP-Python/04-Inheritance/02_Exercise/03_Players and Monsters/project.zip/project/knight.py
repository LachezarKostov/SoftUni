from project import Hero


class Knight(Hero):
    pass
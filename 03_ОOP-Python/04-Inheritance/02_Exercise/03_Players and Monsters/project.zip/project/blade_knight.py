from project import DarkKnight


class BladeKnight(DarkKnight):
    pass

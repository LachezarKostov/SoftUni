from .animal import Animal
from .mammal import Mammal
from .reptile import Reptile


__all__ = ["Animal", "Mammal", "Reptile"]